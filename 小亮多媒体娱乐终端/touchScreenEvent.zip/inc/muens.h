#ifndef _MUENS_H_
#define _MUENS_H_



void getTouchxy(int *x_in, int *y_in, int *x_out, int *y_out);
void getSwipexy(int *x_start, int *y_start, int *x_end, int *y_end);
void picture();
void woodenFish(void);
void Novel(void);



#endif