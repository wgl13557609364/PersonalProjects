#ifndef _TRAJPGPIC_H
#define _TRAJPGPIC_H

pNode trajpgPic(const char *dirPath);

#endif