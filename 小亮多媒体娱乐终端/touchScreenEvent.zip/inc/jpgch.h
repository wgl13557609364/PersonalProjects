#ifndef _JPGCH_H
#define _JPGCH_H


char *jpg2bgr(const char *jpgdata, int jpgsize);


#endif