#ifndef _LCD_H
#define _LCD_H

void LCDInit( void );
void LCDClose(void);


#endif