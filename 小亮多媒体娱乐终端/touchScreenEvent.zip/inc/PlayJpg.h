#ifndef _PLAYJPG_H_
#define _PLAYJPG_H_

#include "datatype.h"

pNode PlayJpg(pNode node,int y_s,int x_s);
pNode Playcard(int y_s, int x_s);


#endif